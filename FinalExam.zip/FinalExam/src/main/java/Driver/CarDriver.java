package Driver;

public class CarDriver {

	private int SadanDriver;
	private int SUVDriver;
	private int MotorcycleDriver;
	private int TruckDriver;

	public int getSadanDriver() {
		// TODO - implement CarDriver.getSadanDriver
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param SadanDriver
	 */
	public void setSadanDriver(int SadanDriver) {
		// TODO - implement CarDriver.setSadanDriver
		throw new UnsupportedOperationException();
	}

	public int getSUVDriver() {
		// TODO - implement CarDriver.getSUVDriver
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param SUVDriver
	 */
	public void setSUVDriver(int SUVDriver) {
		// TODO - implement CarDriver.setSUVDriver
		throw new UnsupportedOperationException();
	}

	public int getMotorcycleDriver() {
		// TODO - implement CarDriver.getMotorcycleDriver
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param MotorcycleDriver
	 */
	public void setMotorcycleDriver(int MotorcycleDriver) {
		// TODO - implement CarDriver.setMotorcycleDriver
		throw new UnsupportedOperationException();
	}

	public int getTruckDriver() {
		// TODO - implement CarDriver.getTruckDriver
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param TruckDriver
	 */
	public void setTruckDriver(int TruckDriver) {
		// TODO - implement CarDriver.setTruckDriver
		throw new UnsupportedOperationException();
	}

}