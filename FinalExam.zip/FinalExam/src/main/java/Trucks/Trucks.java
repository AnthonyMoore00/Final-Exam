package Trucks;

public class Trucks {

	private boolean hasTrailer;
	private float sizeOfTruck;

	public boolean getHasTrailer() {
		return this.hasTrailer;
	}

	/**
	 * 
	 * @param hasTrailer
	 */
	public void setHasTrailer(boolean hasTrailer) {
		this.hasTrailer = hasTrailer;
	}

	public float getSizeOfTruck() {
		return this.sizeOfTruck;
	}

	/**
	 * 
	 * @param sizeOfTruck
	 */
	public void setSizeOfTruck(float sizeOfTruck) {
		this.sizeOfTruck = sizeOfTruck;
	}

}