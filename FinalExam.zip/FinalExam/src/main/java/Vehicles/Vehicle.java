package Vehicles;

public class Vehicle {

	private boolean Sadans;
	private boolean SUVS;
	private boolean Motorcycles;
	private boolean Trucks;

	public boolean getSadans() {
		// TODO - implement Vehicle.getSadans
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Sadans
	 */
	public void setSadans(boolean Sadans) {
		// TODO - implement Vehicle.setSadans
		throw new UnsupportedOperationException();
	}

	public boolean getSUVS() {
		// TODO - implement Vehicle.getSUVS
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param SUVS
	 */
	public void setSUVS(boolean SUVS) {
		// TODO - implement Vehicle.setSUVS
		throw new UnsupportedOperationException();
	}

	public boolean getMotorcycles() {
		// TODO - implement Vehicle.getMotorcycles
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Motorcycles
	 */
	public void setMotorcycles(boolean Motorcycles) {
		// TODO - implement Vehicle.setMotorcycles
		throw new UnsupportedOperationException();
	}

	public boolean getTrucks() {
		// TODO - implement Vehicle.getTrucks
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Trucks
	 */
	public void setTrucks(boolean Trucks) {
		// TODO - implement Vehicle.setTrucks
		throw new UnsupportedOperationException();
	}

}