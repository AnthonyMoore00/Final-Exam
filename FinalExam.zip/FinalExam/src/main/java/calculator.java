
public class calculator {
    public int calculateAverage(int num1, int num2, int num3) {
        int total = num1+num2+num3; 
        int average = total/3; 
        return average; 
    }
}
