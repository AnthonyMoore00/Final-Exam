

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Antho
 */
public class calculatorIT {
    
    public calculatorIT() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    @Test
    public void testCalculateAverage() {
        
      int num1 = 5;
      int num2= 10;
      int num3 = 15; 
      calculator averages = new calculator(); 
      int yourResult = averages.calculateAverage(num1, num2, num3);
      assertEquals(10, yourResult);
    }
    
}
